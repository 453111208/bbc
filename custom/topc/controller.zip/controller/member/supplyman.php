<?php
class topc_ctl_member_supplyman extends topc_ctl_member {
//供求管理




//我的供应信息
   public function needgoods()
	{
        $userInfo = userAuth::getUserInfo();
        $userId = userAuth::id();
        $rows = "*";
        try
            {
                $userMdlAddr = app::get('sysspfb')->model('supplyInfo');
                $goosList =$userMdlAddr->getList($rows,array('user_id'=>$userId));
                $count = $userMdlAddr->count(array('user_id'=>$userId));
            }
         catch(Exception $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
        $pagedata['goosList'] = $goosList;
        $pagedata['goodCounts'] = $count;
      
        $pagedata['action'] = 'topc_ctl_member_supplyman@needgoods';
        $this->action_view = "supplyman/needgoods.html";
        return $this->output($pagedata);
	}

	    /**
    * 供应编辑
    **/
 
        public function editGoods()
    {
             $rows = "*";
             $parent="0";
       // $params['user_id'] = userAuth::id();
         try
            {
               
                $userMdlcat = app::get("sysspfb")->model('cat');
                $catList =   $userMdlcat ->getList($rows,array('parent_id'=>$parent));
            }
         catch(Exception $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
        $pagedata['catList'] = $catList;
        $pagedata['action'] = 'topc_ctl_member_supplyman@editGoods';
        $this->action_view = "supplyman/editGoods.html";
        return $this->output($pagedata);
    }
      /**
    * 供应保存
    **/
        public function SaveGoods(){
            $userId = userAuth::id();
            $postData =utils::_filter_input(input::get());
            $postData['user_id'] = $userId;
            $postData['create_time']=time();
             $postData['approve_stats'] = false;
             $postData['show_stats'] = false;
             $postData['product_intro'] = $_POST["product_intro"];
            try
            {
                $userMdlAddr = app::get('sysspfb')->model('supplyInfo');
                $userMdlAddr->save($postData);
            }
            catch(Exception $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }

            $url = url::action('topc_ctl_member_supplyman@needgoods');
            $msg = app::get('topc')->_('添加成功');
            return $this->splash('success',$url,$msg);
        }
//我的供应信息
	 public function wantgoods(){
                $userId = userAuth::id();
                $rows = "*";
                  try
            {
                $userMdlAddr = app::get('sysspfb')->model('requireInfo');
                $goosList =$userMdlAddr->getList($rows,array('user_id'=>$userId));
                $count = $userMdlAddr->count(array('user_id'=>$userId));
            }
         catch(Exception $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
                $pagedata['goosList'] = $goosList;
                $pagedata['goodCounts'] = $count;
                $pagedata['action'] = 'topc_ctl_member_supplyman@wantgoods';
                $this->action_view = "supplyman/wantgoods.html";
                return $this->output($pagedata);
        }









     public function eidtRequireGoods()
    {
       // $params['user_id'] = userAuth::id();
            $rows = "*";
             $parent="0";
       // $params['user_id'] = userAuth::id();
         try
            {
               
                $userMdlcat = app::get("sysspfb")->model('cat');
                $catList =   $userMdlcat ->getList($rows,array('parent_id'=>$parent));
            }
         catch(Exception $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
        $pagedata['catList'] = $catList;
        $pagedata['action'] = 'topc_ctl_member_supplyman@eidtRequireGoods';
        $this->action_view = "supplyman/eidtRequireGoods.html";
        return $this->output($pagedata);
    }

      public function SaveRequireGoods(){
            $userId = userAuth::id();
            $postData =utils::_filter_input(input::get());
            $postData['user_id'] = $userId;
            $postData['create_time']=time();
             $postData['approve_stats'] = false;
              $postData['show_stats'] = false;
               $postData['product_intro'] = $_POST["product_intro"];
            try
            {
                $userMdlAddr = app::get('sysspfb')->model('requireInfo');
                $userMdlAddr->save($postData);
            }
            catch(Exception $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }

            $url = url::action('topc_ctl_member_supplyman@wantgoods');
            $msg = app::get('topc')->_('添加成功');
            return $this->splash('success',$url,$msg);
        }




}