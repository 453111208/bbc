<?php
class topc_ctl_member_shoppubt extends topc_ctl_member {

//我发布的交易 
	 public function shoppubtList()
	 {
        $pagedata['action'] = 'topc_ctl_member_shoppubt@shoppubtList';
        $this->action_view = "shoppubt/list.html";
        $userId = userAuth::id();

        return $this->output($pagedata);
	 }

// 添加标准商品的发布交易
	public function addStandards(){
        $pagedata['uniqid']=uniqid();
		$pagedata['action'] = 'topc_ctl_member_shoppubt@shoppubtList';
        $this->action_view = "shoppubt/addStandards.html";
        return $this->output($pagedata);
	}

//添加竞价
	public function addBidding(){
        $pagedata['uniqid']=uniqid();
		$pagedata['action'] = 'topc_ctl_member_shoppubt@shoppubtList';
        $this->action_view = "shoppubt/bidding_or_tender.html";
        return $this->output($pagedata);
	}
//添加招标
	public function addTender(){
         $pagedata['uniqid']=uniqid();
		$pagedata['action'] = 'topc_ctl_member_shoppubt@shoppubtList';
        $this->action_view = "tender/tender_index.html";
        return $this->output($pagedata);
	}
 
//添加地址 dialog
	public function addr_dialog()
    {
        $pagedata['asd']='test';
        return view::make('topc/member/shoppubt/add_address.html',$pagedata);
    }

//选择商品分类 dialog
    public function sGodds()
    {
        $rows = "*";
        $parent="0";
         try
            {
               
                $userMdlcat = app::get("syscategory")->model('cat');
                $catList =   $userMdlcat ->getList($rows,array('parent_id'=>$parent));
            }
         catch(Exception $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();
                return $this->splash('error',null,$msg);
            }
        $pagedata['action'] = 'topc_ctl_member_goods@addGoods';
        $pagedata['catList'] =$catList;
         return view::make('topc/member/shoppubt/sGoods.html',$pagedata);
    }


//saveAddress
	public function  saveAddress(){
		$userId = userAuth::id();
        $postData = input::get();
        $addritem=app::get('sysshoppubt')->model('deliveryaddr');
        $postData['area'] = rtrim(input::get()['area'][0],',');
        $postData['user_id'] = $userId;
        $postData['create_time']=time();
        $area = app::get('topc')->rpcCall('logistics.area',array('area'=>$postData['area']));
        if($area)
        {
            $areaId =  str_replace(",","/", $postData['area']);
            $postData['area'] = $area . ':' . $areaId;
        }
        else
        {
            $msg = app::get('topc')->_('地区不存在!');
            return $this->splash('error',null,$msg);
        }
        try
        {  
       $filter = array('uniqid' => $postData['uniqid']);
        if($postData['def_addr'])
        {
            $arrUpdate = array('def_addr'=>0);
            $addritem->update($arrUpdate, $filter);
        }
        if( $postData['uniqid'])
        {
        $addritem->save($postData);
        }

        $filter1['uniqid']=$postData['uniqid'];
        $userAddrList=$addritem->getList('*',$filter1);
        foreach ($userAddrList as &$addr) {
            list($regions,$region_id) = explode(':', $addr['area']);
            $addr['region_id'] = str_replace('/', ',', $region_id);
        }
        $pagedata['userAddrList'] = $userAddrList;
        return view::make('topc/member/shoppubt/add_edit.html',$pagedata);
        }
        catch(Exception $e)
        {
            $msg = $e->getMessage();

            return $this->splash('error',null,$msg);
        }
        
	}

    public function saveS(){
        $postData = input::get();
        $user_id = userAuth::id();
        
switch ($postData['stop_time']) {
    case 'one':
        $postData['through_time']=strtotime("+1 month");
        break;
    case 'three':
        $postData['through_time']=strtotime("+3 month");
        break;  
    case 'six':
     $postData['through_time']=strtotime("+6 month");
        break;
    case 'december':
    $postData['through_time']=strtotime("+12 month");
        break;      
    case 'effective':
    $postData['through_time']=strtotime("+120 month");
        break;      
}
        $arr['stop_time']=time();
        $arr['uniqid']=$postData['uniqid'];
        $arr['trading_title']=$postData['trading_title'];
        $arr['price_type']=$postData['price_type'];
        $arr['fund_trend']=$postData['fund_trend']; 
        $arr['create_time']=time();
        $arr['shop_id']=$user_id;
        $arr['shop_name']='1';
        try
        {
        $saveItem = app::get('sysshoppubt')->model('sprodrelease');
        $saveItem->save($arr);

        $item_ids=$postData['item_id'];
        $units=$postData['unit'];
        $standardg_item_ids=$postData['standardg_item_id'];
        $i=0;
        $itemmodel = app::get('sysshoppubt')->model('standard_item');
        $db=app::get('sysshoppubt')->database();
        foreach ($item_ids as $key => $item_id) {
            $item=array();
            // $item['standardg_item_id']=;
            $sql="update sysshoppubt_standard_item set unit = '".$units[$i]."' where standardg_item_id = ".$standardg_item_ids[$i];
            $db->exec($sql);
        $i++;
        }

        }
            catch(Exception $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }

        $url = url::action('topc_ctl_member_shoppubt@addStandards');
        $msg = app::get('topc')->_('添加成功');
        return $this->splash('success',$url,$msg);

    }

}

