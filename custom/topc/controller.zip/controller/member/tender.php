
<?php
class topc_ctl_member_tender extends topc_ctl_member{




     public function saveS(){
        $postData = input::get();
        $user_id = userAuth::id();
        $arr['uniqid']=$postData['uniqid'];
        $arr['trading_title']=$postData['trading_title'];
        // $arr['start_time']=$postData['start_time'];
        // $arr['stop_time']=$postData['stop_time'];

        $arr['start_time']=time();
         $arr['stop_time']=time();
        $arr['price_type']=$postData['price_type'];
        $arr['advice']=$postData['advice']; 
        $arr['trade_type']=$postData['trade_type']; 
        $arr['add_price']=$postData['add_price']; 
        $arr['ensurence']=$postData['ensurence']; 
        $arr['fund_trend']=$postData['fund_trend'];
        $arr['public_item']=$postData['public_item'];
        $arr['limitation']=$postData['limitation']; 
        $arr['create_time']=time();
        $arr['shop_id']=$user_id;
        $arr['shop_name']='1';
        try
        {
        $saveItem = app::get('sysshoppubt')->model('tender');
        $saveItem->save($arr);

        $item_ids=$postData['item_id'];
        $units=$postData['unit'];
        $standardg_item_ids=$postData['standardg_item_id'];
        $net_prices=$postData['net_price'];
        $fixed_prices=$postData['fixed_price'];
        $i=0;
        $itemmodel = app::get('sysshoppubt')->model('standard_item');
        $db=app::get('sysshoppubt')->database();
        foreach ($item_ids as $key => $item_id) {
            $item=array();
            $sql="update sysshoppubt_standard_item set unit = '".$units[$i]."' , net_price =".$net_prices[$i]." ,  fixed_price =".$fixed_prices[$i]." where standardg_item_id = ".$standardg_item_ids[$i];
            $db->exec($sql);
        $i++;
        }

        }
            catch(Exception $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }
            catch(\LogicException $e)
            {
                $msg = $e->getMessage();

                return $this->splash('error',null,$msg);
            }

        $url = url::action('topc_ctl_member_shoppubt@addTender');
        $msg = app::get('topc')->_('添加成功');
        return $this->splash('success',$url,$msg);

    }
}