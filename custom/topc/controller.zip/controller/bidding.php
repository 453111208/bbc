<?php
/**
 * ShopEx licence
 *
 * @copyright  Copyright (c) 2005-2010 ShopEx Technologies Inc. (http://www.shopex.cn)
 * @license  http://ecos.shopex.cn/ ShopEx License
 */

class topc_ctl_bidding extends topc_controller {

	public function index(){
		$bidddingId = intval(input::get('bidding_id'));# code...
		if( empty($bidddingId) )
        	{
            	return redirect::action('topc_ctl_default@index');
        	}
        	 	if( userAuth::check() )
        	{
           	$pagedata['nologin'] = 1;
        	}
        	$biddingItem= app::get("sysshoppubt")->model("biddings")->getRow("*",array("bidding_id"=>$bidddingId ));
        	$biddingItemList = app::get("sysshoppubt")->model("standard_item")->getList("*",array("uniqid"=>$biddingItem['uniqid'] ));
        	$pagedata["requireItem"]=$biddingItem;
        	$pagedata["itemList"] = $biddingItemList;
        	$id=$biddingItem["bidding_id"];
   	$sql = "select  b_price from sysshoppubt_biddingsitems  where biddings_id=".$id." order by b_price desc  limit 1";
   	$biddingList = app::get("base")->database()->executeQuery($sql)->fetchAll();
   	$a = $biddingList[0];
   	$pagedata["b_price"] = $a['b_price'];
        	 $article_id = "1";
           $artList = app::get("syscontent")->model("article")->getList("*",array('article_id'=>$article_id));
           $pagedata["artList"]=$artList[0]['content'];
            
            $article_id = "2";
            $artList = app::get("syscontent")->model("article")->getList("*",array('article_id'=>$article_id));
            $pagedata["dialogPrice"]=$artList[0]['content'];
            
        	return $this->page('topc/bidding/index.html', $pagedata);
	}
}