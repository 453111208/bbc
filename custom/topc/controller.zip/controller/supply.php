<?php
/**
 * ShopEx licence
 *
 * @copyright  Copyright (c) 2005-2010 ShopEx Technologies Inc. (http://www.shopex.cn)
 * @license  http://ecos.shopex.cn/ ShopEx License
 */

class topc_ctl_supply extends topc_controller {

	public function index()
	{
	$supplyId = intval(input::get('supply_id'));# code...
	$type=intval(input::get('type'));# code...
	if( empty($supplyId) )
        	{
            	return redirect::action('topc_ctl_default@index');
        	}
        	if( userAuth::check() )
        	{
           	$pagedata['nologin'] = 1;
        	}
        	$supplyItem= app::get("sysspfb")->model("supplyInfo")->getRow("*",array("supply_id"=>$supplyId ));
        	$pagedata["requireItem"]=$supplyItem;
        	$pagedata["type"] = $type;

            
         //   var_dump( $type);
        	return $this->page('topc/items/index.html', $pagedata);

	}
}
