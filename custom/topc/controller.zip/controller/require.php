<?php
/**
 * ShopEx licence
 *
 * @copyright  Copyright (c) 2005-2010 ShopEx Technologies Inc. (http://www.shopex.cn)
 * @license  http://ecos.shopex.cn/ ShopEx License
 */

class topc_ctl_require extends topc_controller {

	public function index()
	{
	$requireId = intval(input::get('require_id'));# code...
	$type=intval(input::get('type'));# code...
	if( empty($requireId) )
        	{
            		return redirect::action('topc_ctl_default@index');
        	}
        	if( userAuth::check() )
        	{
           		$pagedata['nologin'] = 1;
        	}
        	$requireItem= app::get("sysspfb")->model("requireInfo")->getRow("*",array("require_id"=>$requireId ));
        	$pagedata["requireItem"]=$requireItem;
        	$pagedata["type"] = $type;
        	return $this->page('topc/items/index.html', $pagedata);

	}
}
