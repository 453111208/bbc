<?php
class sysnotice_mdl_notice_type extends dbeav_model{

}