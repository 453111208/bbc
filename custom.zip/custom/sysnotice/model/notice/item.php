<?php
class sysnotice_mdl_notice_item extends dbeav_model{

}