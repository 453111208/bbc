<?php
class sysitem_mdl_item_status extends dbeav_model{

    public function _filter($filter,$tableAlias=null,$baseWhere=null){
        return parent::_filter($filter);
    }

}

