<?php 
	class sysexpert_mdl_literarycat extends dbeav_model{

	}
