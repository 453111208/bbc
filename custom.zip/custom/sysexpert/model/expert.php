<?php 
	class sysexpert_mdl_expert extends dbeav_model{

	}
