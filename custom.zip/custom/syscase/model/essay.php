<?php 
	class syscase_mdl_essay extends dbeav_model{

	}
