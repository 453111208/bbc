<?php 
	class syscase_mdl_essaycat extends dbeav_model{

	}
