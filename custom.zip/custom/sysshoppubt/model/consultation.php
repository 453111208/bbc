<?php
class sysshoppubt_mdl_consultation extends dbeav_model{

	}