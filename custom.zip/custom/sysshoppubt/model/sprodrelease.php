<?php
class sysshoppubt_mdl_sprodrelease extends dbeav_model{

	
}