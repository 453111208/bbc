<?php
class sysshoppubt_mdl_checks extends dbeav_model{

	
}