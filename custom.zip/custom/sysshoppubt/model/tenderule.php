<?php
class sysshoppubt_mdl_tenderule extends dbeav_model{
	
}