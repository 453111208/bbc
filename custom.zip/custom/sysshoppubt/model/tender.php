<?php
class sysshoppubt_mdl_tender extends sysshoppubt_mdl_sprodrelease{
	
}