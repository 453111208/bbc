<?php
class sysshoppubt_mdl_tenderinfo extends dbeav_model{

	
}