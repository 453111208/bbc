<?php
class sysshoppubt_mdl_moneyrecoder extends dbeav_model{

	
}