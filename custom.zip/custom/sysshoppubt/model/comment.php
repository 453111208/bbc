<?php
class sysshoppubt_mdl_comment extends dbeav_model{

	}