<?php
class sysshoppubt_mdl_tenderenter extends dbeav_model{

	
}