<?php
class sysshoppubt_mdl_mffb extends dbeav_model{

	
}