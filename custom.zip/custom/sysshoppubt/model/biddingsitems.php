<?php
class sysshoppubt_mdl_biddingsitems extends dbeav_model{

	
}