<?php
class sysshoppubt_mdl_standard_item extends dbeav_model{

}