<?php
class sysshoppubt_mdl_detail extends dbeav_model{

	
}