<?php
class sysshoppubt_mdl_sample extends dbeav_model{

	
}