<?php
class sysshoppubt_mdl_chrule extends dbeav_model{

	
}