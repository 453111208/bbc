<?php
class sysshoppubt_mdl_biddings extends dbeav_model{

	
}