<?php
class sysshoppubt_mdl_tradeorder extends dbeav_model{
	
}