<?php
class sysshoppubt_mdl_torderitem extends dbeav_model{
	
}