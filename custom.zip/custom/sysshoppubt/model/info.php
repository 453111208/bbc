<?php
class sysshoppubt_mdl_info extends dbeav_model{

	
}