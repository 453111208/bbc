<?php
class sysshoppubt_mdl_deliveryaddr extends dbeav_model{

	
}