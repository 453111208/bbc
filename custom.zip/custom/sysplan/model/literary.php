<?php 
	class sysplan_mdl_literary extends dbeav_model{
            var $defaultOrder = array('click_count','DESC');

	}
