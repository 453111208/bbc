<?php 
	class sysplan_mdl_literarytarget extends dbeav_model{

	}
