<?php 
	class sysplan_mdl_literaryclass extends dbeav_model{

	}
