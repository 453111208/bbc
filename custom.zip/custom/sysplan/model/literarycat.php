<?php 
	class sysplan_mdl_literarycat extends dbeav_model{

	}
