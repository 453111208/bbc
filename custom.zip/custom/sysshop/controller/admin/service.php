<?php
/**
 * @brief 第三方文章
 */
class sysshop_ctl_admin_service extends desktop_controller {

    /**
     * @brief  第三方服务列表
     *
     * @return
     */
    public function index()
    {
        return $this->finder('sysshop_mdl_service',array(
            'use_buildin_delete' => true,
            'title' => app::get('sysshop')->_('第三方服务列表'),
            'actions'=>array(
                /*
                 * 暂时注释此处，遗留后用
                 array(
                     'label'=>'发送邮件短信',
                     'submit'=>'?app=sysshop&ctl=admin_seller&act=messenger',
                 ),
                 */
                array(
                    'label'=>app::get('sysshop')->_('添加第三方服务'),
                    'href'=>'?app=sysshop&ctl=admin_service&act=addArticle',
                    'target'=>'dialog::{title:\''.app::get('sysshop')->_('添加第三方服务').'\',  width:600,height:320}',
                ),
            ),
        ));
    }

    public function addArticle(){
        $this->contentHeaderTitle = '添加第三方服务';
        return view::make('sysshop/admin/shop/service.html',$pagedata);
    }
    public function save(){
        $data = input::get();
        $third = app::get('sysshop')->model('service');
        $data['modified'] = time();
        if(!$data['article_id']){
        $data['pubtime'] = time();
        $this->begin("?app=sysshop&ctl=admin_service&act=index");
        try {
            $third->save($data);
        } catch (Exception $e) {
            $msg = $e->getMessage();
            $this->end(false,$msg);
        }
        $this->end(success,"保存成功");
        }else{
            $service = $third->getRow('*',array('article_id'=>$data['article_id']));
        $this->begin("?app=sysshop&ctl=admin_service&act=index");
            try {
            $third->update($data,$service);
            } catch (Exception $e) {
            $msg = $e->getMessage();
            $this->end(false,$msg);
            }
        $this->end(success,"保存成功");
        }
    }
    public function edit(){
        $data = input::get();
        $service = app::get('sysshop')->model('service');
        $serviceinfo = $service->getRow('*',array('article_id'=>$data['article_id']));
        $pagedata['row'] = $serviceinfo;
        $this->contentHeaderTitle = '修改第三方服务';
        return view::make('sysshop/admin/shop/service.html',$pagedata);
    }
}