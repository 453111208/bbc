<?php
class sysshop_mdl_service extends dbeav_model{
	
}