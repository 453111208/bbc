<?php

class sysshop_mdl_shop_rel_lv1cat extends dbeav_model{

}

