<?php
class sysshop_mdl_enterprise extends dbeav_model{

}